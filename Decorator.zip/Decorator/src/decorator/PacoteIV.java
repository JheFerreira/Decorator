/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorator;
import interfaces.IAssinatura;

/**
 *
 * @author Jéssica Ferreira
 */
public class PacoteIV extends Pacote{

    public PacoteIV(IAssinatura pacote) {
        super(pacote);
    }

    @Override
    public String getServico() {
        return super.getServico() + "\nPacote 4";
    }

    @Override
    public double getPrice() {
        return super.getPrice() + 49.99;
    }

    @Override
    public String getDescricao() {
        return super.getDescricao() + "\n - Cartão de crédito Platinum.";
    }
    
}
