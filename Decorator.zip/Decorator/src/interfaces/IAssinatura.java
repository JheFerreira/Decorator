/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

/**
 *
 * @author Jéssica Ferreira
 */
public interface IAssinatura {
    
    public double getPrice();
    public String getServico();
    public String getDescricao();
    
}
