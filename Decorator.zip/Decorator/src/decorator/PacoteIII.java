/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorator;
import interfaces.IAssinatura;

/**
 *
 * @author Jéssica Ferreira
 */
public class PacoteIII extends Pacote{

    public PacoteIII(IAssinatura pacote) {
        super(pacote);
    }

    @Override
    public String getServico() {
        return super.getServico() + "\nPacote 3";
    }

    @Override
    public double getPrice() {
        return super.getPrice() + 29.99;
    }

    @Override
    public String getDescricao() {
        return super.getDescricao() + "\n - Caixa surpresa com produtos relacionados a filmes e série.";
    }
    
}
